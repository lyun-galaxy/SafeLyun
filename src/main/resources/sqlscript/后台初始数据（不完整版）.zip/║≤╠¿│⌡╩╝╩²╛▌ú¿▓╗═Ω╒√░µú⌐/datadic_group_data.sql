/*
-- Query: SELECT * FROM safelyun.datadic_groups
LIMIT 0, 1000
数据字典分组数据，数据未经校验
-- Date: 2016-05-05 15:05
*/
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('0','学院');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('01','文学与传媒学院');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('014','汉语言文学');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('015','广播电视新闻学');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('016','对外汉语');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('02','外国语学院');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('024','英语');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('025','日语');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('03','信息工程学院');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('031','数学与应用数学');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('032','计算机科学与技术');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('033','信息与计算科学');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('034','软件工程');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('04','物理与机电工程学院');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('042','机电一体化技术');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('044','物理学');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('045','电子信息工程');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('047','机械设计制造及其自动化');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('05','经济与管理学院');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('054','市场营销');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('055','公共事业管理');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('056','国际经济与贸易');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('06','化学与材料学院');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('065','化学');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('066','材料科学与工程');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('067','应用化学');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('07','体育系');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('070','体育教育');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('08','生命科学学院');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('085','生物技术');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('086','生物科学');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('087','动物医学');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('088','动物科学');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('09','资源工程学院');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('096','采矿工程');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('097','地质工程');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('098','测绘工程');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('10','教育科学学院');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('106','心理学');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('11','艺术系');
INSERT INTO `datadic_groups` (`group_code`,`group_name`) VALUES ('116','采矿工程');
