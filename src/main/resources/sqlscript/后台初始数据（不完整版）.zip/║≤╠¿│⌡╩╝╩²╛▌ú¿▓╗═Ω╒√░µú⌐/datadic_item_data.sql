/*
-- Query: SELECT * FROM safelyun.datadic_items
LIMIT 0, 1000
数据字典项数据，数据未经过校验
班级数据项未插入
还需插入班级数据项格式：
'0345','软件工程1班','034'
-- Date: 2016-05-05 15:08
*/
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('01','文学与传媒学院','0');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('014','汉语言文学','01');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('015','广播电视新闻学','01');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('016','对外汉语','01');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('02','外国语学院','0');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('024','英语','02');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('025','日语','02');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('03','信息工程学院','0');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('031','数学与应用数学','03');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('032','计算机科学与技术','03');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('033','信息与计算科学','03');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('034','软件工程','03');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('0345','软件工程1班','034');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('0346','软件工程1班','034');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('04','物理与机电工程学院','0');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('042','机电一体化技术','04');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('044','物理学','04');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('047','机械设计制造及其自动化','04');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('05','经济与管理学院','0');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('054','市场营销','05');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('055','公共事业管理','05');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('056','国际经济与贸易','05');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('06','化学与材料学院','0');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('065','化学','06');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('066','材料科学与工程','06');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('067','应用化学','06');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('07','体育系','0');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('070','体育教育','07');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('08','生命科学学院','0');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('085','生物技术','08');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('086','生物科学','08');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('088','动物医学','08');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('09','资源工程学院','0');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('096','采矿工程','09');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('097','地质工程','09');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('098','测绘工程','09');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('10','教育科学学院','0');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('106','心理学','10');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('11','艺术系','11');
INSERT INTO `datadic_items` (`item_code`,`item_name`,`datadic_groups_group_code`) VALUES ('116','采矿工程','11');
