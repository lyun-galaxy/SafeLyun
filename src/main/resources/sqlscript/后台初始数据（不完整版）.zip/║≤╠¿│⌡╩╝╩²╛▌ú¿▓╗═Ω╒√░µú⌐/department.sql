/*
-- Query: SELECT * FROM safelyun.department
LIMIT 0, 1000
院系表模板数据
-- Date: 2016-05-05 15:29
*/
INSERT INTO `department` (`departmentId`,`departmentName`) VALUES (3,'信息工程学院');
