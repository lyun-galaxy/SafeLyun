/*
-- Query: SELECT * FROM safelyun.specialty
LIMIT 0, 1000
专业表模板数据
-- Date: 2016-05-05 15:29
*/
INSERT INTO `specialty` (`specialtyId`,`specialtyName`,`department_departmentId`) VALUES (34,'软件工程',3);
