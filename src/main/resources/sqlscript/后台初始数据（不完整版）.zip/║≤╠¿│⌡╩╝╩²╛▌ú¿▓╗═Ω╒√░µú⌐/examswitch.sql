/*
-- Query: SELECT * FROM safelyun.examswitch
LIMIT 0, 1000

-- Date: 2016-05-05 15:16
*/
INSERT INTO `examswitch` (`examswitchId`,`switchOnOrOff`) VALUES (1,'0');
