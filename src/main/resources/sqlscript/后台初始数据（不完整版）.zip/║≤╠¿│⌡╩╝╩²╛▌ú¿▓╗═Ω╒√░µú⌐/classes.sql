/*
-- Query: SELECT * FROM safelyun.classes
LIMIT 0, 1000
班级表模板数据
-- Date: 2016-05-05 15:29
*/
INSERT INTO `classes` (`classesId`,`classesName`,`specialty_specialtyId`) VALUES (345,'软件工程1班',34);
INSERT INTO `classes` (`classesId`,`classesName`,`specialty_specialtyId`) VALUES (346,'软件工程2班',34);
